# Workforce Competency Management Portal - Final Prototype

Start: open index.html in a browser after extracting the ZIP.

Authentication flow:
- Existing Administrator Login remains intact.
- Use "Register as Administrator" to open the government-style registration flow.
- Registration captures Center/State, Ministry/Department, Organisation, Designation and official email.
- Step 2 verifies a prototype OTP (123456).
- Successful registration stores a demo administrator locally and returns to login.
- Login then accepts the registered demo credentials.

All analytics in this package are prototype/demo data. Production deployment should connect SSO/identity federation, server-side RBAC, database services and real ML/predictive APIs.
