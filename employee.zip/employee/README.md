# Skill Intelligence Frontend

This frontend is organized so the Employee UI can connect to a backend/database without redesigning the pages.

## Employee data kept together

The main employee record contains:

- employee profile: id, name, role, department, organisation, experience, email
- current competency profile
- assessment result
- courseProgress: course id -> percentage completed
- completedVideos: videos watched by the employee

## Database integration point

`app.js` contains an `employeeStore` object. For the hackathon demo it uses frontend state. When the backend/database is ready, replace the methods in `employeeStore` with API calls.

The UI already reads from this single employee record for:

- Current Competency
- Recommended Courses
- Learning Progress
- My Learning
- Videos watched
- Skill Gaps
- Future Skill Requirements
- Assessment results

## Course behaviour

Every course has:

- a unique `id`
- eligible `roles`
- AI/data-intelligence `skills`
- course description
- lesson/video names
- duration and level

Recommended courses are filtered by the employee role and ranked using current skill gaps and future-skill requirements.

Course cards are clickable. `Open Course`, `Continue`, and the course card itself open the course detail page. Watching a video updates course progress and the watched-video record.

## Start the Employee Portal

Open `index.html` directly. The Employee Dashboard loads without a login/register screen; authentication can be integrated later with the main application backend.

