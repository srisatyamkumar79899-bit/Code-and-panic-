/*
  Skill Intelligence Platform - database-ready employee frontend
  ---------------------------------------------------------------
  The UI reads employee-specific information from state.employee through
  employeeStore. Later, replace employeeStore methods with API/database calls
  without changing the page components.
*/

const portalSession = JSON.parse(localStorage.getItem("sip_session") || "null");
if (!portalSession || portalSession.role !== "employee") {
  window.location.replace("../index.html");
}

function logout() {
  localStorage.removeItem("sip_session");
  window.location.href = "../index.html";
}

const roleDefaults = {
  "Statistician": {
    dept:"Ministry of Statistics & Programme Implementation",
    future:[
      {name:"AI-Assisted Statistical Analysis", why:"AI tools may increasingly support survey analysis, anomaly detection and faster statistical reporting.", prepare:"Learn how to validate AI outputs and combine them with statistical methods."},
      {name:"Advanced Data Analytics", why:"Larger and more complex official datasets will require stronger analytical workflows.", prepare:"Strengthen Python, SQL and analytical reasoning for large datasets."},
      {name:"Cloud Data Platforms", why:"Government data workflows are moving toward secure, scalable digital platforms.", prepare:"Understand cloud-based data storage, access and processing concepts."},
      {name:"Data Visualization & Storytelling", why:"Future roles will increasingly turn statistical results into clear policy insights.", prepare:"Build dashboards and communicate evidence clearly to decision-makers."}
    ],
    current:[
      ["Survey Design",74],["Sampling",68],["Python",56],["SQL",49],
      ["Data Visualization",63],["Data Quality",71]
    ]
  },
  "Data Analyst": {
    dept:"Ministry of Statistics & Programme Implementation",
    future:[
      {name:"AI-Assisted Data Analysis", why:"Analysts will increasingly use AI for exploration, summarization and pattern discovery.", prepare:"Learn prompting, validation and AI-supported analytical workflows."},
      {name:"Advanced SQL & Data Engineering", why:"More connected government datasets require stronger querying and data preparation skills.", prepare:"Practise SQL joins, transformations and data-quality checks."},
      {name:"Cloud Analytics", why:"Scalable analytics workloads may increasingly run on secure cloud platforms.", prepare:"Understand cloud data warehouses, pipelines and access controls."},
      {name:"GIS & Open Data Analytics", why:"Location-based official statistics can support planning and public policy.", prepare:"Learn GIS concepts and combine spatial data with statistical analysis."}
    ],
    current:[
      ["Data Visualization",76],["SQL",69],["Python",61],["Survey Design",44],
      ["GIS",38],["Data Quality",66]
    ]
  },
  "Assistant Director": {
    dept:"Ministry of Statistics & Programme Implementation",
    future:[
      {name:"AI Strategy for Government Data", why:"Leaders may need to guide responsible use of AI in evidence-based public programmes.", prepare:"Understand AI opportunities, limitations, governance and evaluation."},
      {name:"Predictive & Advanced Analytics", why:"Forecasting and scenario analysis can support planning and resource decisions.", prepare:"Build comfort with predictive methods and interpretation of model results."},
      {name:"Digital Governance", why:"Government services need strong digital processes, interoperability and accountability.", prepare:"Learn digital governance principles, APIs and secure data exchange."},
      {name:"AI & Data Quality Governance", why:"As AI adoption grows, trustworthy data and responsible validation become more important.", prepare:"Focus on data quality, bias checks, privacy and human review."}
    ],
    current:[
      ["Survey Design",82],["Data Quality",79],["Leadership",71],["AI/ML",42],
      ["Cloud Computing",35],["Cybersecurity",51]
    ]
  }
};

// Every course is tagged to one or more government roles AND has an AI/data-intelligence angle.
const courses = [
  {id:"c01",title:"AI for Official Statistics",domain:"AI & Statistics",level:"Foundation",hours:5,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Statistics"],description:"Understand where AI can support official statistics, where human validation is needed, and how to use AI responsibly in statistical workflows.",lessons:["AI in statistical workflows","Prompting for evidence tasks","Validating AI-generated results"],theme:"blue"},
  {id:"c02",title:"AI-Assisted Data Analysis with Python",domain:"AI & Technical",level:"Intermediate",hours:7,roles:["Statistician","Data Analyst"],skills:["AI","Python","Analytics"],description:"Use Python and AI-assisted workflows to explore, clean and interpret structured government data.",lessons:["Data exploration","AI-assisted analysis","Quality checks"],theme:"green"},
  {id:"c03",title:"AI-Ready SQL & Data Quality",domain:"AI & Technical",level:"Intermediate",hours:6,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","SQL","Data Quality"],description:"Strengthen SQL and data-quality skills needed before using AI on reliable statistical datasets.",lessons:["SQL foundations","Data validation","AI-ready datasets"],theme:"orange"},
  {id:"c04",title:"AI-Powered Survey Design & Sampling",domain:"AI & Statistical",level:"Intermediate",hours:6,roles:["Statistician","Assistant Director"],skills:["AI","Survey Design","Sampling"],description:"Explore how AI can assist survey planning while keeping statistical design, sampling quality and human review at the centre.",lessons:["Survey planning","Sampling checks","AI-assisted review"],theme:"orange"},
  {id:"c05",title:"AI & Data Visualization for Policy",domain:"AI & Analytics",level:"Intermediate",hours:5,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Visualization","Policy"],description:"Turn official statistics into clear dashboards and policy stories using AI-assisted exploration and visualization techniques.",lessons:["Choosing visuals","AI-assisted storytelling","Policy dashboards"],theme:"green"},
  {id:"c06",title:"AI, GIS & Open Data Analytics",domain:"AI & Spatial Analytics",level:"Intermediate",hours:7,roles:["Data Analyst","Statistician"],skills:["AI","GIS","Open Data"],description:"Combine spatial data, open datasets and AI-assisted analysis to identify geographic patterns relevant to public programmes.",lessons:["GIS basics","Spatial data","AI-assisted pattern finding"],theme:"blue"},
  {id:"c07",title:"Cloud & AI Data Platforms",domain:"AI & Cloud",level:"Intermediate",hours:6,roles:["Data Analyst","Assistant Director","Statistician"],skills:["AI","Cloud","Data Platforms"],description:"Build practical understanding of how secure cloud platforms can support scalable data and AI workloads.",lessons:["Cloud data concepts","Secure access","AI workloads"],theme:"blue"},
  {id:"c08",title:"Responsible AI for Government Data",domain:"AI & Governance",level:"Foundation",hours:4,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Privacy","Governance"],description:"Learn practical checks for privacy, bias, explainability and human oversight when AI is used with government data.",lessons:["Responsible AI","Privacy basics","Human-in-the-loop review"],theme:"orange"},
  {id:"c09",title:"AI Strategy & Digital Governance",domain:"AI & Leadership",level:"Advanced",hours:5,roles:["Assistant Director"],skills:["AI","Governance","Leadership"],description:"Understand how leaders can evaluate AI opportunities, set governance expectations and align technology with organisational goals.",lessons:["AI strategy","Governance","Implementation planning"],theme:"green"},
  {id:"c10",title:"Predictive Analytics with AI Support",domain:"AI & Advanced Analytics",level:"Advanced",hours:8,roles:["Assistant Director","Data Analyst","Statistician"],skills:["AI","Predictive Analytics","Python"],description:"Build an applied understanding of forecasting and predictive workflows with AI-assisted exploration and human validation.",lessons:["Forecasting","Model interpretation","AI-assisted analysis"],theme:"blue"}
];


// NSSTA course integration point. Replace sourceUrl/moduleId with real API data later.
const NSSTA_BASE_URL = "https://nssta.gov.in";
const defaultRoleCourses = [
{id:"ns01",title:"AI-Enabled Communication for Statistical Officials",domain:"NSSTA • Communication",level:"Foundation",hours:3,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Communication"],description:"Build clear, evidence-based communication skills with AI-assisted drafting and review.",lessons:["Communicating statistical findings","AI-assisted briefing drafts","Human review and accuracy"],theme:"blue",provider:"NSSTA",sourceUrl:NSSTA_BASE_URL,assignmentTags:["communication","reporting","presentation"]},
{id:"ns02",title:"AI, Leadership & Decision Support",domain:"NSSTA • Leadership",level:"Foundation",hours:4,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Leadership"],description:"Develop leadership and decision-support skills for AI-enabled official statistical work.",lessons:["Leading data-driven teams","AI-assisted decision support","Responsible leadership review"],theme:"green",provider:"NSSTA",sourceUrl:NSSTA_BASE_URL,assignmentTags:["leadership","decision"]},
{id:"ns03",title:"Role-Based AI Skills for Official Statistics",domain:"NSSTA • Role Skills",level:"Foundation",hours:4,roles:["Statistician","Data Analyst","Assistant Director"],skills:["AI","Role Competency"],description:"Strengthen AI-enabled competencies relevant to your government statistics role.",lessons:["Role competency mapping","AI tools for your role","Applying learning to assignments"],theme:"orange",provider:"NSSTA",sourceUrl:NSSTA_BASE_URL,assignmentTags:["competency","role"]}
];
courses.push(...defaultRoleCourses);

const employeeSeed = {
  id:"emp-demo-001",
  name:"Ananya Sharma",
  role:"Statistician",
  dept:roleDefaults["Statistician"].dept,
  org:"National Statistical Office",
  experience:"6 years",
  email:"ananya.sharma@gov.in",
  competencyOverride:null,
  courseProgress:{c01:78,c02:64,c03:38,c04:22,c05:0,c06:0,c07:0,c08:100,c09:0,c10:0},
  completedVideos:[
    {courseId:"c01",title:"AI in Official Statistical Work",progress:100,watchedOn:"Today"},
    {courseId:"c08",title:"Responsible AI: Human Review & Privacy",progress:100,watchedOn:"Yesterday"},
    {courseId:"c02",title:"AI-assisted Python Data Exploration",progress:72,watchedOn:"2 days ago"}
  ],
  assessment:{done:false,score:0,lastUpdated:null}
};

let state = {
  screen:"home",
  authMode:null,
  user:null,
  employee:JSON.parse(JSON.stringify(employeeSeed)),
  selectedCourseId:null,
  toastTimer:null,
  quizIndex:0,
  score:0,
  selected:null,
  sidebarOpen:true,
  aiOpen:false,
  aiMessages:[{role:"assistant",text:"Hi! I’m your Skill Intelligence assistant. Upload a PDF, presentation, document, spreadsheet, or image and ask me to summarize, explain, create study notes, make questions, or find learning actions."}],
  aiFiles:[],
  // Admin dashboard integration point: populate this from your secure Gemini backend.
  aiUsage:{requests:0,inputTokens:0,outputTokens:0,estimatedCost:0}
};

// Database integration point. Swap these in the backend phase.
const employeeStore = {
  get(){ return state.employee; },
  update(patch){ state.employee={...state.employee,...patch}; return state.employee; },
  updateCourseProgress(courseId, progress){
    state.employee.courseProgress={...state.employee.courseProgress,[courseId]:Math.max(0,Math.min(100,progress))};
    return state.employee.courseProgress[courseId];
  },
  addVideoWatch(record){
    const old=state.employee.completedVideos.filter(v=>!(v.courseId===record.courseId && v.title===record.title));
    state.employee.completedVideos=[record,...old];
  }
};

function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function initials(name){return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();}
function defaultUser(){
  const e=employeeStore.get();
  return {name:e.name,role:e.role,dept:e.dept,org:e.org,experience:e.experience,email:e.email};
}
function roleData(){return roleDefaults[state.employee.role]||roleDefaults["Statistician"];}
function courseById(id){return courses.find(c=>c.id===id);}
function roleCourses(){return courses.filter(c=>c.roles.includes(state.employee.role));}

// Future-skill courses use the same course catalogue/player as Recommended Courses.
// When the backend is connected, these IDs can come from the employee/future-skill API response.
const futureCourseMap={
  "AI-Assisted Statistical Analysis":["c01","c02","c10"],
  "Advanced Data Analytics":["c02","c03","c10"],
  "Cloud Data Platforms":["c07"],
  "Data Visualization & Storytelling":["c05"],
  "AI-Assisted Data Analysis":["c01","c02","c10"],
  "Advanced SQL & Data Engineering":["c03"],
  "Cloud Analytics":["c07"],
  "GIS & Open Data Analytics":["c06"],
  "AI Strategy for Government Data":["c09","c01"],
  "Predictive & Advanced Analytics":["c10"],
  "Digital Governance":["c09","c08"],
  "AI & Data Quality Governance":["c08","c03"]
};
function futureCourses(skill){
  const ids=futureCourseMap[skill.name]||[];
  return ids.map(courseById).filter(Boolean).filter(c=>c.roles.includes(state.employee.role));
}
function progressPercent(){
  const list=roleCourses();
  if(!list.length)return 0;
  return Math.round(list.reduce((sum,c)=>sum+(Number(state.employee.courseProgress[c.id])||0),0)/list.length);
}
function learningHoursCompleted(){
  const list=roleCourses();
  return Math.round((list.reduce((sum,c)=>sum+((Number(state.employee.courseProgress[c.id])||0)/100)*c.hours,0))*10)/10;
}
function completedCourseCount(){return roleCourses().filter(c=>(Number(state.employee.courseProgress[c.id])||0)>=100).length;}
function currentCompetencyScore(){
  const vals=roleData().current.map(x=>x[1]);
  const baseline=Math.round(vals.reduce((a,b)=>a+b,0)/vals.length);
  if(!state.employee.assessment?.done)return baseline;
  const assessmentPct=Math.round((state.employee.assessment.score/quiz.length)*100);
  return Math.min(100,Math.round((baseline+assessmentPct)/2));
}
function skillGaps(){
  const current=Object.fromEntries(roleData().current);
  const likely=["SQL","AI/ML","AI","Cloud Computing","GIS","Data Quality","Python","Sampling"];
  return likely.filter(k=>{
    const key=current[k]!==undefined?k:null;
    if(key)return current[key]<65;
    if(k==="AI"&&current["AI/ML"]!==undefined)return current["AI/ML"]<65;
    return false;
  }).slice(0,5).map(skill=>({skill,priority:(skill==="SQL"||skill==="GIS"?"High":"Medium")}));
}
function recommendedCourses(){
  const d=roleData();
  const hasLearning=Object.values(state.employee.courseProgress||{}).some(v=>Number(v)>0);
  const gaps=skillGaps().map(x=>x.skill.toLowerCase().replace("ai/ml","ai"));
  return roleCourses().slice().sort((a,b)=>{
    const score=c=>{
      const text=(c.title+' '+c.domain+' '+c.skills.join(' ')).toLowerCase();
      const gapScore=gaps.reduce((n,g)=>n+(text.includes(g)?5:0),0);
      const futureScore=d.future.reduce((n,f)=>n+(text.includes(f.name.split(' ')[0].toLowerCase())?2:0),0);
      const inProgress=(state.employee.courseProgress[c.id]||0)>0 ? 1 : 0;
      const completed=(state.employee.courseProgress[c.id]||0)>=100 ? -3 : 0;
      const assignmentDone=!!state.employee.assessment?.done;
      const assignmentScore=assignmentDone && c.assignmentTags?.some(t=>text.includes(t)) ? 4 : 0;
      const defaultBoost=!hasLearning && c.provider==="NSSTA" ? 3 : 0;
      return gapScore+futureScore+assignmentScore+defaultBoost-inProgress+completed;
    };
    return score(b)-score(a);
  }).slice(0,6);
}
function lastOrNextLearning(){
  const list=roleCourses().filter(c=>(state.employee.courseProgress[c.id]||0)<100);
  return list.sort((a,b)=>(state.employee.courseProgress[b.id]||0)-(state.employee.courseProgress[a.id]||0))[0] || roleCourses()[0];
}

function layout(content, active="home"){
  const nav=[
    ["home","⌂","Home"],["learning","▣","My Learning"],["competencies","◉","Competencies"],
    ["gaps","△","Skill Gaps"],["recommendations","★","Recommended Courses"],
    ["assessment","✓","Assessment"],["progress","↗","Progress"],["profile","○","Profile"]
  ];
  const open=state.sidebarOpen;
  return `<div class="app-shell ${open?'sidebar-open':'sidebar-closed'} ${state.aiOpen?'ai-open':''}"><header class="topbar">
    <div class="topbar-left"><button class="icon-btn menu-toggle" aria-label="${open?'Close':'Open'} sidebar" onclick="toggleSidebar()">${open?'☰':'☰'}</button><div class="brand"><div class="brand-mark">SI</div><div><strong>Skill Intelligence Platform</strong><span>Official Statistics • Government Learning</span></div></div></div>
    <div class="actions"><span class="gov-chip">Secure Government Portal</span><button class="ai-toggle" aria-expanded="${state.aiOpen}" onclick="toggleAssistant()"><span>✦</span> AI Assistant</button><button class="btn btn-secondary" onclick="logout()">Log out</button></div>
  </header><div class="layout"><aside class="sidebar"><div class="sidebar-head"><div class="nav-title">Employee Portal</div><button class="sidebar-close" aria-label="Close sidebar" onclick="toggleSidebar()">×</button></div>
    ${nav.map(([id,ico,label])=>`<button class="nav-btn ${active===id?'active':''}" onclick="navigate('${id}')"><span class="ico">${ico}</span><span class="nav-label">${label}</span></button>`).join("")}
    <div class="side-bottom"><strong>Role-based + AI learning</strong><br><small>Recommendations, progress and future skills are stored against this employee profile.</small></div>
  </aside><main class="content">${content}</main></div>${renderAssistant()}</div>`;
}

function renderAssistant(){
  return `<aside class="ai-drawer" aria-label="AI assistant">
    <div class="ai-drawer-head"><div><div class="ai-avatar">✦</div><div><strong>Learning Assistant</strong><span><i></i> Online · Ready to help</span></div></div><button class="ai-close" aria-label="Close AI assistant" onclick="toggleAssistant()">×</button></div>
    <div class="ai-messages" id="aiMessages">${state.aiMessages.map(m=>`<div class="ai-message ${m.role}">${escapeHtml(m.text)}</div>`).join("")}</div>
    <div class="ai-upload"><input id="aiFileInput" type="file" multiple accept=".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx,.csv,.txt,.png,.jpg,.jpeg,.webp" onchange="handleAssistantFiles(this.files)"><label for="aiFileInput"><span>＋</span><strong>Upload learning material</strong><small>PDF, PPT, DOC, XLS, CSV, images or text</small></label>${state.aiFiles.length?`<div class="ai-file-list">${state.aiFiles.map((file,index)=>`<div class="ai-file"><span>▧</span><div><strong>${escapeHtml(file.name)}</strong><small>${formatFileSize(file.size)}</small></div><button aria-label="Remove ${escapeHtml(file.name)}" onclick="removeAssistantFile(${index})">×</button></div>`).join("")}</div>`:""}</div>
    <div class="ai-suggestions"><button onclick="askAssistant('Show my learning progress')">My progress</button><button onclick="askAssistant('What course should I take next?')">Recommend a course</button><button onclick="askAssistant('Help with my profile')">My profile</button></div>
    <form class="ai-composer" onsubmit="sendAssistantMessage(event)"><input id="aiInput" aria-label="Message AI assistant" placeholder="Ask about your learning…" autocomplete="off"><button aria-label="Send message">➤</button></form>
  </aside><button class="ai-fab" aria-label="Open AI assistant" onclick="toggleAssistant()">✦<span>Ask AI</span></button>`;
}

function render(){
  const app=document.getElementById("app");
  let html="";
  if(state.screen==="home") html=layout(renderHome(),"home");
  else if(state.screen==="learning") html=layout(renderLearning(),"learning");
  else if(state.screen==="competencies") html=layout(renderCompetencies(),"competencies");
  else if(state.screen==="gaps") html=layout(renderGaps(),"gaps");
  else if(state.screen==="recommendations") html=layout(renderRecommendations(),"recommendations");
  else if(state.screen==="assessment") html=layout(renderAssessment(),"assessment");
  else if(state.screen==="progress") html=layout(renderProgress(),"progress");
  else if(state.screen==="profile") html=layout(renderProfile(),"profile");
  else if(state.screen==="course") html=layout(renderCourse(),"learning");
  else if(state.screen==="admin") html=layout(renderAdmin(),"home");
  app.innerHTML=html;
}

function syncUserFromEmployee(){state.user=defaultUser();}
function navigate(id, options={}){
  state.screen=id;
  if(!options.fromHistory) history.pushState({screen:id,selectedCourseId:state.selectedCourseId}, "", `#${id}`);
  render();window.scrollTo(0,0);
}
function goBack(){ if(history.length>1) history.back(); else navigate('home'); }
function toggleSidebar(){state.sidebarOpen=!state.sidebarOpen;render();}
function toggleAssistant(){state.aiOpen=!state.aiOpen;render(); if(state.aiOpen) requestAnimationFrame(()=>document.getElementById('aiInput')?.focus());}
function formatFileSize(bytes){return bytes<1024*1024?`${Math.max(1,Math.round(bytes/1024))} KB`:`${(bytes/(1024*1024)).toFixed(1)} MB`;}
function handleAssistantFiles(files){
  const accepted=["application/pdf","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","text/csv","text/plain","image/png","image/jpeg","image/webp"];
  const incoming=Array.from(files).filter(file=>accepted.includes(file.type) || /\.(pdf|pptx?|docx?|xlsx?|csv|txt|png|jpe?g|webp)$/i.test(file.name));
  if(!incoming.length){toast("Choose a supported document, spreadsheet, presentation, image, or text file.");return;}
  state.aiFiles=[...state.aiFiles,...incoming].slice(0,10);
  state.aiMessages.push({role:"assistant",text:`${incoming.length} file${incoming.length>1?"s are":" is"} ready. Ask what you would like me to do with the uploaded material.`});
  render();
}
function removeAssistantFile(index){state.aiFiles.splice(index,1);render();}
function assistantReply(text){
  const message=text.toLowerCase();
  if(message.includes("progress")) return `You are ${progressPercent()}% through your role-based learning, with ${learningHoursCompleted()} learning hours completed.`;
  if(message.includes("course") || message.includes("recommend")) { const c=recommendedCourses()[0]; return c ? `I recommend “${c.title}” next. It matches your role and current skill priorities.` : "Your recommended courses will appear here once your learning profile is ready."; }
  if(message.includes("profile")) return `Your profile is set to ${state.employee.role} at ${state.employee.org}. You can update or review it from the Profile page.`;
  return "I can help with your courses, competencies, assessment, progress, and profile. Try asking what you should learn next.";
}
function askAssistant(text){
  state.aiMessages.push({role:"user",text});
  // Replace this local response with a call to your backend (/api/ai/chat). Send aiFiles there,
  // then store returned usage data in state.aiUsage for the future admin cost dashboard.
  state.aiUsage.requests++;
  state.aiMessages.push({role:"assistant",text:state.aiFiles.length?`I’ll use your ${state.aiFiles.length} uploaded file${state.aiFiles.length>1?"s":""} with that request. ${assistantReply(text)}`:assistantReply(text)});
  render();
}
function sendAssistantMessage(event){event.preventDefault();const input=document.getElementById('aiInput');const text=input?.value.trim();if(text)askAssistant(text);}

function renderHome(){
  const d=roleData(), future=d.future.slice(0,3), next=lastOrNextLearning();
  return `<div class="page-head"><div><h1>Welcome back, ${escapeHtml(state.employee.name)}</h1><p>${escapeHtml(state.employee.role)} • ${escapeHtml(state.employee.dept)}</p></div><div class="actions"><button class="btn btn-secondary" onclick="navigate('profile')">View Profile</button><button class="btn btn-primary" onclick="navigate('assessment')">${state.employee.assessment.done?'View Skills Check Result':'Personalize My Learning Plan'}</button></div></div>
  <div class="banner"><div><h2>${state.employee.assessment.done?'Your recommendations are now more precise.':'Personalize your learning plan'}</h2><p>${state.employee.assessment.done?'Your skills-check result is now part of your employee learning profile.':'Take a short skills check to refine your learning priorities and course recommendations.'}</p></div><button class="btn btn-orange" onclick="navigate('assessment')">${state.employee.assessment.done?'Review Result':'Start Skills Check'}</button></div>
  <div class="grid grid-3">
    <button class="card metric metric-link" onclick="navigate('competencies')"><div class="label">Current Competency</div><div class="value">${currentCompetencyScore()}%</div><div class="sub">${state.employee.assessment.done?'Updated from assessment':'Role-based baseline'} <span>→</span></div></button>
    <button class="card metric metric-link" onclick="navigate('recommendations')"><div class="label">Recommended Courses</div><div class="value">${recommendedCourses().length}</div><div class="sub">Role + AI aligned <span>→</span></div></button>
    <button class="card metric metric-link" onclick="navigate('progress')"><div class="label">Learning Progress</div><div class="value">${progressPercent()}%</div><div class="sub">${learningHoursCompleted()} learning hours <span>→</span></div></button>
  </div>
  <div class="section-title"><h2>Start Your Learning</h2><button class="link" onclick="navigate('recommendations')">View all</button></div>
  <p class="small" style="margin:-4px 0 12px">Begin with these courses based on your role and learning needs.</p>
  <div class="course-row">${roleCourses().slice(0,4).map(courseCard).join("")}</div>
  <div class="section-title"><h2>Skills to Build Next</h2><button class="link" onclick="navigate('competencies')">Explore</button></div>
  <div class="grid grid-3">${future.map(x=>`<div class="card"><span class="badge badge-orange">Future Skill</span><h3 style="margin-top:12px">${escapeHtml(x.name)}</h3><p>${escapeHtml(x.why)}</p><div class="section-title" style="margin-top:12px"><h2 style="font-size:16px">Future-focused learning</h2></div><div class="course-row">${futureCourses(x).slice(0,1).map(courseCard).join("")}</div></div>`).join("")}</div>
  <div class="section-title"><h2>Recommended courses</h2><button class="link" onclick="navigate('recommendations')">View all</button></div>
  <div class="course-row">${recommendedCourses().slice(0,4).map(courseCard).join("")}</div>
  ${next?`<div class="section-title"><h2>Stay on Track</h2></div><div class="card momentum-card"><div><strong>Next best step: ${escapeHtml(next.title)}</strong><p class="small">You are ${state.employee.courseProgress[next.id]||0}% through this course. One more focused session can move your learning forward.</p></div><button class="btn btn-primary" onclick="openCourse('${next.id}')">Resume Learning</button></div>`:''}`;
}

function courseCard(c){
  const p=Number(state.employee.courseProgress[c.id])||0;
  return `<div class="course" onclick="openCourse('${c.id}')" role="button" tabindex="0" onkeydown="if(event.key==='Enter')openCourse('${c.id}')"><div class="course-top ${c.theme||'blue'}"><span class="badge badge-${c.theme==='green'?'green':c.theme==='orange'?'orange':'blue'}">${escapeHtml(c.domain)}</span></div><div class="course-body"><div class="course-title">${escapeHtml(c.title)}</div><div class="course-meta">${escapeHtml(c.level)} • ${c.hours} hrs • ${p}% complete</div><div class="progress" style="margin-top:10px"><span style="width:${p}%"></span></div><div class="course-foot"><span class="small">${escapeHtml(c.provider||"Role + AI")}${c.provider==="NSSTA"?" • Role-based":""}</span><button class="btn btn-secondary" onclick="event.stopPropagation();openCourse('${c.id}')">${p>0&&p<100?'Continue':p>=100?'Review':'Open Course'}</button></div></div></div>`;
}

function renderLearning(){
  const next=lastOrNextLearning();
  return `<div class="page-head"><div><h1>My Learning</h1><p>Your courses, progress and next actions are saved to your employee learning profile.</p></div><div class="actions"><button class="btn btn-secondary" onclick="goBack()">← Back</button><button class="btn btn-primary" onclick="navigate('recommendations')">Browse Recommended Courses</button></div></div>
  <div class="grid grid-4"><div class="card metric"><div class="label">Overall learning</div><div class="value">${progressPercent()}%</div><div class="sub">Role-aligned course progress</div></div><div class="card metric"><div class="label">Learning hours</div><div class="value">${learningHoursCompleted()}</div><div class="sub">Learning activity</div></div><div class="card metric"><div class="label">Courses completed</div><div class="value">${completedCourseCount()}</div><div class="sub">Role catalogue</div></div></div>
  <div class="section-title"><h2>Resume Your Learning</h2></div>
  <div class="grid grid-2"><div class="card resume-card" ${next?`role="button" tabindex="0" onclick="openCourse('${next.id}')" onkeydown="if(event.key==='Enter')openCourse('${next.id}')"`:''}>${next?`<h3>${escapeHtml(next.title)}</h3><p>${escapeHtml(next.description)}</p><div class="row" style="margin-top:14px"><span class="small">${state.employee.courseProgress[next.id]||0}% complete</span><button class="btn btn-primary" onclick="event.stopPropagation();openCourse('${next.id}')">Resume Learning</button></div>`:'<h3>All courses completed</h3><p>Great work. Revisit a course or take the competency assessment again.</p>'}</div>
  <div class="card"><h3>Keep going</h3><p>${motivationMessage()}</p><div class="progress" style="margin-top:14px"><span style="width:${progressPercent()}%"></span></div><p class="small" style="margin-top:8px">${remainingLearningMessage()}</p></div></div>
  <div class="section-title"><h2>My role-aligned courses</h2></div><div class="course-row">${roleCourses().map(courseCard).join("")}</div>`;
}
function motivationMessage(){
  const p=progressPercent();
  if(p>=80)return "You are close to completing your learning cycle. Finish the remaining modules, then reassess your competencies.";
  if(p>=50)return "You already have strong momentum. Keep completing one focused course session at a time.";
  if(p>0)return "You have started your journey. Every completed learning activity adds to the learning record that guides your next recommendation.";
  return "Start with one role + AI course today. Your first completed lesson gives the system useful learning data for the next step.";
}
function remainingLearningMessage(){return `${Math.max(0,100-progressPercent())}% of the role catalogue remains. Your progress will update here as you complete learning activities and courses.`;}

function renderCompetencies(){
  const d=roleData(), values=d.current, overall=currentCompetencyScore();
  return `<div class="page-head"><div><h1>Competency Profile</h1><p>Current competencies are linked to your role and can be updated after assessment and learning.</p></div><button class="btn btn-primary" onclick="navigate('assessment')">${state.employee.assessment.done?'Retake Assessment':'Complete Assignment'}</button></div>
  <div class="grid grid-3"><div class="card metric"><div class="label">Overall competency</div><div class="value">${overall}%</div><div class="sub">Employee profile score</div></div><div class="card metric"><div class="label">Current skill areas</div><div class="value">${values.length}</div><div class="sub">Role-based competencies</div></div><div class="card metric"><div class="label">Identified skill gaps</div><div class="value">${skillGaps().length}</div><div class="sub">Priorities for learning</div></div></div>
  <div class="section-title"><h2>Current competencies</h2></div><div class="card">${values.map(([name,val])=>`<div class="skill-line"><div class="row"><span>${escapeHtml(name)}</span><strong>${val}%</strong></div><div class="progress"><span style="width:${val}%"></span></div></div>`).join("")}</div>
  <div class="section-title"><div><h2>What future skills may you face?</h2><p class="small">Future-focused learning paths based on your role. Select a course to open the same learning player used by Recommended Courses.</p></div></div>
  <div class="grid grid-2">${d.future.map(x=>`<div class="card"><span class="badge badge-orange">Future Skill</span><h3 style="margin-top:12px">${escapeHtml(x.name)}</h3><p>${escapeHtml(x.why)}</p><div class="section-title" style="margin-top:16px"><h2 style="font-size:16px">Future-focused learning</h2></div><div class="course-row">${futureCourses(x).map(courseCard).join("")}</div></div>`).join("")}</div>`;
}

function renderGaps(){
  const gaps=skillGaps();
  return `<div class="page-head"><div><h1>Skill Gap Analysis</h1><p>${state.employee.assessment.done?'Gaps are informed by your role and latest assessment.':'These are preliminary role-based gaps; complete the assignment for a more precise profile.'}</p></div><button class="btn btn-primary" onclick="navigate('assessment')">${state.employee.assessment.done?'Retake Assessment':'Start Assessment'}</button></div>
  <div class="card table-wrap"><table><thead><tr><th>Skill</th><th>Priority</th><th>Recommended action</th></tr></thead><tbody>${gaps.map(g=>`<tr><td><strong>${escapeHtml(g.skill)}</strong></td><td><span class="badge ${g.priority==='High'?'badge-red':'badge-orange'}">${g.priority}</span></td><td>Learn the relevant role + AI course</td></tr>`).join("")}</tbody></table></div>
  <div class="section-title"><h2>Courses for these gaps</h2></div><div class="course-row">${recommendedCourses().map(courseCard).join("")}</div>`;
}

function renderRecommendations(){
  return `<div class="page-head"><div><h1>Recommended Courses</h1><p>Every course below is selected from your role and its AI-enabled future skill requirements.</p></div></div>
  <div class="card" style="margin-bottom:18px"><strong>Recommendation flow:</strong> employee role → current competencies → assignment results → skill gaps → future skill requirements → role + AI course recommendations → learning progress.<br><span class="small">NSSTA training modules are included where relevant. New employees start with default role-based AI learning; completing the assignment makes recommendations more precise.</span></div>
  <div class="course-row">${recommendedCourses().map(courseCard).join("")}</div>
  <div class="section-title"><div><h2>Future-focused learning</h2><p class="small">Courses connected to the skills your role may need next. These use the same API-ready course catalogue and player.</p></div></div><div class="grid grid-2">${roleData().future.map(x=>`<div class="card"><span class="badge badge-orange">Future Skill</span><h3 style="margin-top:12px">${escapeHtml(x.name)}</h3><p>${escapeHtml(x.why)}</p><div class="course-row">${futureCourses(x).map(courseCard).join("")}</div></div>`).join("")}</div>`;
}

function openCourse(id){
  if(!courseById(id)){toast("Course could not be opened");return;}
  state.selectedCourseId=id; navigate("course");
}
function renderCourse(){
  const c=courseById(state.selectedCourseId); if(!c)return `<div class="card"><h2>Course not found</h2><button class="btn btn-primary" onclick="navigate('recommendations')">Back to Courses</button></div>`;
  const p=Number(state.employee.courseProgress[c.id])||0;
  return `<div class="page-head"><div><button class="link" onclick="goBack()">← Back</button><h1 style="margin-top:10px">${escapeHtml(c.title)}</h1><p>${escapeHtml(c.domain)} • ${escapeHtml(c.level)} • ${c.hours} hrs</p></div><div class="actions"><span class="badge badge-blue">Role + AI aligned</span>${c.sourceUrl?`<a class="btn btn-secondary" href="${escapeHtml(c.sourceUrl)}" target="_blank" rel="noopener">Open NSSTA Module</a>`:''}</div></div>
  <div class="grid grid-2"><div class="card"><span class="badge badge-orange">AI-enabled learning</span><h2>${escapeHtml(c.title)}</h2><p>${escapeHtml(c.description)}</p><div class="section-title"><h2 style="font-size:16px">Course videos</h2></div>${c.lessons.map((lesson,i)=>{const vp=i<c.lessons.length-1?Math.min(100,Math.max(0,p-(i*34))):p;return `<div class="skill-line"><div class="row"><span>${i+1}. ${escapeHtml(lesson)}</span><strong>${vp}%</strong></div><div class="progress"><span style="width:${vp}%"></span></div><button class="btn btn-secondary" style="margin-top:7px" onclick="watchVideo('${c.id}',${i})">${vp>=100?'Watch again':'Watch video'}</button></div>`}).join("")}</div>
  <div class="card"><h3>Your progress</h3><div class="value" style="font-size:40px;margin:12px 0">${p}%</div><div class="progress"><span style="width:${p}%"></span></div><p style="margin-top:14px">${p>=100?'Course completed. Consider reassessing to update your competency profile.':`Complete the videos to keep your learning record current. You have ${100-p}% remaining.`}</p>
  <div class="section-title"><h2 style="font-size:16px">Why this course is recommended</h2></div><div class="tag-list">${c.skills.map(s=>`<span class="badge badge-blue">${escapeHtml(s)}</span>`).join("")}</div>
  ${p<100?`<button class="btn btn-primary" style="margin-top:18px" onclick="watchVideo('${c.id}',${Math.min(c.lessons.length-1,Math.floor((p/100)*c.lessons.length))})">Start / Continue Video</button>`:`<button class="btn btn-primary" style="margin-top:18px" onclick="navigate('assessment')">Reassess Competencies</button>`}</div></div>`;
}
function watchVideo(courseId,index){
  const c=courseById(courseId); if(!c)return;
  const completed=Math.min(100,Math.round(((index+1)/c.lessons.length)*100));
  employeeStore.updateCourseProgress(courseId,Math.max(Number(state.employee.courseProgress[courseId])||0,completed));
  employeeStore.addVideoWatch({courseId,title:c.lessons[index],progress:completed,watchedOn:"Today"});
  render(); toast(`${c.lessons[index]} marked as watched`);
}

const quiz=[
  {q:"Which technology can help analyse structured official statistical data?",options:["SQL","Graphic Design","Video Editing","Audio Mixing"],ans:0},
  {q:"What should happen after identifying a competency gap?",options:["Ignore it","Recommend targeted learning","Delete profile","Disable dashboard"],ans:1},
  {q:"Which information can help create a competency profile?",options:["Designation and work experience","Favorite movie","Phone wallpaper","Browser theme"],ans:0},
  {q:"Why is AI used carefully in official statistics?",options:["It should replace all human checks","AI output needs validation and responsible use","It removes the need for quality checks","It is only for entertainment"],ans:1}
];
function renderAssessment(){
  if(state.employee.assessment.done) return `<div class="page-head"><div><h1>Assessment Results</h1><p>Your latest assignment result is saved to your employee profile.</p></div><button class="btn btn-secondary" onclick="startAssessment()">Retake</button></div><div class="grid grid-3"><div class="card metric"><div class="label">Assessment score</div><div class="value">${state.employee.assessment.score}/${quiz.length}</div><div class="sub">Latest attempt</div></div><div class="card metric"><div class="label">Current competency</div><div class="value">${currentCompetencyScore()}%</div><div class="sub">Updated profile</div></div><div class="card metric"><div class="label">Recommended next</div><div class="value">${recommendedCourses().length}</div><div class="sub">Role + AI courses</div></div></div><div class="section-title"><h2>Next learning path</h2></div><div class="card"><p>Focus first on the highest-priority gaps, then continue into future-skill modules that match your role.</p><button class="btn btn-primary" style="margin-top:14px" onclick="navigate('recommendations')">View Recommendations</button></div>`;
  return `<div class="page-head"><div><h1>Competency Assessment</h1><p>Answer a few questions to refine the employee competency and learning profile.</p></div><span class="badge badge-orange">Question ${state.quizIndex+1} of ${quiz.length}</span></div><div class="card"><h2 style="margin-top:0">${quiz[state.quizIndex].q}</h2><div style="margin-top:16px">${quiz[state.quizIndex].options.map((o,i)=>`<button class="quiz-option ${state.selected===i?'selected':''}" onclick="selectAnswer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}</div><div style="display:flex;justify-content:space-between;align-items:center;margin-top:18px"><span class="small">Result will be stored with this employee profile.</span><button class="btn btn-primary" onclick="nextQuestion()">${state.quizIndex===quiz.length-1?'Finish Assessment':'Next'}</button></div></div>`;
}
function startAssessment(){state.employee.assessment={done:false,score:0,lastUpdated:null};state.quizIndex=0;state.score=0;state.selected=null;state.screen="assessment";render();}
function selectAnswer(i){state.selected=i;render();}
function nextQuestion(){
  if(state.selected===null){toast("Select an answer first");return;}
  if(state.selected===quiz[state.quizIndex].ans)state.score++;
  if(state.quizIndex===quiz.length-1){
    state.employee.assessment={done:true,score:state.score,lastUpdated:new Date().toISOString()}; state.screen="assessment"; state.selected=null; render(); toast("Assignment completed. Your learning profile is updated.");
  }else{state.quizIndex++;state.selected=null;render();}
}

function renderProgress(){
  const list=roleCourses();
  return `<div class="page-head"><div><h1>Learning Progress</h1><p>Track course completion, videos watched, learning hours and competency growth.</p></div></div><div class="grid grid-4"><div class="card metric"><div class="label">Overall progress</div><div class="value">${progressPercent()}%</div><div class="sub">Across role courses</div></div><div class="card metric"><div class="label">Learning hours</div><div class="value">${learningHoursCompleted()}</div><div class="sub">Calculated from course progress</div></div><div class="card metric"><div class="label">Courses completed</div><div class="value">${completedCourseCount()}</div><div class="sub">Out of ${list.length}</div></div><div class="card metric"><div class="label">Assessment score</div><div class="value">${state.employee.assessment.done?Math.round((state.employee.assessment.score/quiz.length)*100):'—'}${state.employee.assessment.done?'%':''}</div><div class="sub">Latest attempt</div></div></div><div class="grid grid-2" style="margin-top:18px"><div class="card"><h3>Current learning</h3>${list.map(c=>`<div class="skill-line"><div class="row"><span>${escapeHtml(c.title)}</span><strong>${state.employee.courseProgress[c.id]||0}%</strong></div><div class="progress"><span style="width:${state.employee.courseProgress[c.id]||0}%"></span></div></div>`).join("")}</div><div class="card"><h3>Learning momentum</h3><div class="ring-wrap"><div class="ring" style="background:conic-gradient(var(--blue) 0 ${progressPercent()}%,#e9eef5 ${progressPercent()}% 100%)"></div><div class="ring-value">${progressPercent()}%</div></div><p style="margin-top:14px">${motivationMessage()}</p></div></div>`;
}

function renderProfile(){
  const e=employeeStore.get(), d=roleData();
  const gapRows=d.current.map(([skill,current])=>({skill,current,target:100,gap:Math.max(0,100-current),priority:current<50?'High':current<70?'Medium':'Low'}));
  return `<div class="page-head"><div><h1>My Profile</h1><p>Your employee information, competency gaps and future learning needs.</p></div><div class="actions"><button class="btn btn-secondary" onclick="goBack()">← Back</button><button class="btn btn-primary" onclick="navigate('assessment')">${state.employee.assessment.done?'Retake Assessment':'Complete Assignment'}</button></div></div>
  <div class="profile-grid"><div class="card"><div class="profile-avatar">${initials(e.name)}</div><h2 style="margin-bottom:4px">${escapeHtml(e.name)}</h2><div class="small">${escapeHtml(e.role)}</div><div class="tag-list"><span class="badge badge-blue">${escapeHtml(e.org)}</span></div><div style="margin-top:18px"><div class="small">Government Email</div><strong>${escapeHtml(e.email)}</strong></div><div style="margin-top:12px"><div class="small">Department</div><strong>${escapeHtml(e.dept)}</strong></div><div style="margin-top:12px"><div class="small">Experience</div><strong>${escapeHtml(e.experience)}</strong></div></div>
  <div class="card"><div class="section-title" style="margin-top:0"><div><h2>Skill Gap Analysis</h2><p class="small">Current competency compared with the target level. ${state.employee.assessment.done?'Updated from your latest assessment.':'Complete the assignment to refine these values.'}</p></div></div><div class="table-wrap"><table><thead><tr><th>Skill</th><th>Current Competency</th><th>Target Level</th><th>Skill Gap</th><th>Priority</th></tr></thead><tbody>${gapRows.map(g=>`<tr><td><strong>${escapeHtml(g.skill)}</strong></td><td>${g.current}%</td><td>${g.target}%</td><td>${g.gap}%</td><td><span class="badge ${g.priority==='High'?'badge-red':g.priority==='Medium'?'badge-orange':'badge-green'}">${g.priority}</span></td></tr>`).join('')}</tbody></table></div></div></div>
  <div class="section-title"><h2>Skills to Build Next</h2><button class="link" onclick="navigate('competencies')">Explore</button></div>
  <div class="future-grid">${d.future.slice(0,4).map(f=>`<div class="card future-card"><span class="badge badge-orange">AI-identified future skill</span><h3 style="margin-top:12px">${escapeHtml(f.name)}</h3><p>${escapeHtml(f.why)}</p><div class="small" style="margin-top:12px"><strong>Prepare:</strong> ${escapeHtml(f.prepare)}</div>${futureCourses(f.name).length?`<div class="future-course-list"><div class="small"><strong>Future-focused learning</strong></div>${futureCourses(f.name).slice(0,2).map(c=>`<button class="mini-course" onclick="openCourse('${c.id}')"><span>${escapeHtml(c.title)}</span><span>View Course →</span></button>`).join('')}</div>`:''}</div>`).join('')}</div>`;
}
function renderAdmin(){const usage=state.aiUsage;return `<div class="page-head"><div><h1>Administrator Dashboard</h1><p>Organization-wide workforce competency and training insights.</p></div><span class="badge badge-orange">Admin View</span></div><div class="grid grid-4"><div class="card metric admin-card"><div class="label">Employees</div><div class="value">1,248</div><div class="sub">Active profiles</div></div><div class="card metric admin-card"><div class="label">Avg competency</div><div class="value">71%</div><div class="sub">Across workforce</div></div><div class="card metric admin-card"><div class="label">Training completion</div><div class="value">64%</div><div class="sub">Current cycle</div></div><div class="card metric admin-card"><div class="label">Emerging skills</div><div class="value">12</div><div class="sub">Priority areas</div></div></div><div class="section-title"><h2>Competency distribution</h2></div><div class="grid grid-2"><div class="card">${["Statistical","Technical","Digital Governance","Behavioural & Managerial"].map((x,i)=>`<div class="skill-line"><div class="row"><span>${x}</span><strong>${[78,63,57,72][i]}%</strong></div><div class="progress"><span style="width:${[78,63,57,72][i]}%"></span></div></div>`).join("")}</div><div class="card"><h3>Future workforce requirements</h3><div class="tag-list"><span class="badge badge-orange">AI / ML</span><span class="badge badge-orange">Cloud</span><span class="badge badge-orange">GIS</span><span class="badge badge-orange">APIs</span><span class="badge badge-orange">Cybersecurity</span></div><p style="margin-top:13px">Use workforce trends to prioritize future capacity-building programmes.</p></div></div><div class="section-title"><h2>Gemini AI usage and cost</h2></div><div class="grid grid-4"><div class="card metric admin-card"><div class="label">AI requests</div><div class="value">${usage.requests}</div><div class="sub">Current session</div></div><div class="card metric admin-card"><div class="label">Input tokens</div><div class="value">${usage.inputTokens.toLocaleString()}</div><div class="sub">From Gemini backend</div></div><div class="card metric admin-card"><div class="label">Output tokens</div><div class="value">${usage.outputTokens.toLocaleString()}</div><div class="sub">From Gemini backend</div></div><div class="card metric admin-card"><div class="label">Estimated AI cost</div><div class="value">$${usage.estimatedCost.toFixed(2)}</div><div class="sub">Populate from Gemini usage metadata</div></div></div>`;}

function toast(msg){
  const old=document.querySelector('.toast'); if(old)old.remove();
  const el=document.createElement('div'); el.className='toast'; el.textContent=msg; document.body.appendChild(el);
  clearTimeout(state.toastTimer); state.toastTimer=setTimeout(()=>el.remove(),2200);
}

state.employee=JSON.parse(JSON.stringify(employeeSeed));
state.user=defaultUser();
const initialScreen=location.hash.slice(1);
const validScreens=["home","learning","competencies","gaps","recommendations","assessment","progress","profile","admin"];
if(validScreens.includes(initialScreen)) state.screen=initialScreen;
history.replaceState({screen:state.screen,selectedCourseId:state.selectedCourseId}, "", `#${state.screen}`);
render();

window.addEventListener("popstate", event=>{
  const previous=event.state;
  if(previous?.screen){
    state.screen=previous.screen;
    state.selectedCourseId=previous.selectedCourseId||null;
  }else{
    const screen=location.hash.slice(1);
    state.screen=validScreens.includes(screen)?screen:"home";
  }
  render();window.scrollTo(0,0);
});

window.navigate=navigate;
window.goBack=goBack;
window.toggleSidebar=toggleSidebar;
window.toggleAssistant=toggleAssistant;
window.askAssistant=askAssistant;
window.sendAssistantMessage=sendAssistantMessage;
window.handleAssistantFiles=handleAssistantFiles;
window.removeAssistantFile=removeAssistantFile;
window.startAssessment=startAssessment;
window.selectAnswer=selectAnswer;
window.nextQuestion=nextQuestion;
window.openCourse=openCourse;
window.watchVideo=watchVideo;
window.logout=logout;
